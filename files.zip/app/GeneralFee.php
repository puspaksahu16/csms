<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GeneralFee extends Model
{
    protected $guarded = [];
}
