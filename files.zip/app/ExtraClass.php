<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExtraClass extends Model
{
    protected $guarded = [];
}
