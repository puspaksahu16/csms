<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class idproof extends Model
{
    protected $guarded = [];
}
